package com.example.azfantasypl;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.content.Intent;

public class HomePage extends AppCompatActivity {

    String username;
    private HomeFragment homeFragment;
    private MyTeamFragment myteamFragment;

    private TextView mTextMessage;
    private TextView points;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        Bundle extras = getIntent().getExtras();
        if(extras != null) {
            username = extras.getString("user");
        }

        homeFragment = new HomeFragment();
        myteamFragment = new MyTeamFragment();

        switchFragment(homeFragment);

//        points = (TextView) findViewById(R.id.tv_points);
//        points.setText("100 PTS");
//        mTextMessage = (TextView) findViewById(R.id.message);
//        mTextMessage.setText("welcome " + username);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.bottom_Nav);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    switchFragment(homeFragment);
                    return true;
                case R.id.navigation_myteam:
                    switchFragment(myteamFragment);
                    return true;
                case R.id.navigation_logout:
                    logout();
                    return true;
            }
            return false;
        }
    };

    public void logout(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private void switchFragment(Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frame_main, fragment);
        fragmentTransaction.commit();
    }
}

package com.example.azfantasypl;

import android.view.View;

public interface ItemClickListener {

    void onItemClick(View v, int pos);
}
